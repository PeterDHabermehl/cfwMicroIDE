<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>addcodeline</name>
    <message>
        <location filename="startide.py" line="2537"/>
        <source>New cmd:</source>
        <translation>Neuer Befehl:</translation>
    </message>
    <message>
        <location filename="startide.py" line="2553"/>
        <source>Inputs</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="2566"/>
        <source>Outputs</source>
        <translation>Ausgänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="2589"/>
        <source>Controls</source>
        <translation>Steuerung</translation>
    </message>
    <message>
        <location filename="startide.py" line="2610"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="2626"/>
        <source>Interaction</source>
        <translation>Interaktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="2562"/>
        <source>WaitForInputDig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2563"/>
        <source>IfInputDig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2582"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2583"/>
        <source>Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2584"/>
        <source>MotorPulsew.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2585"/>
        <source>MotorEnc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2586"/>
        <source>MotorEncSync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2602"/>
        <source># comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2603"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2604"/>
        <source>Jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2605"/>
        <source>LoopTo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2606"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2607"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2621"/>
        <source>Call</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2622"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2623"/>
        <source>Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2624"/>
        <source>MEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2627"/>
        <source>Interact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2639"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2641"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2642"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2640"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ecl</name>
    <message>
        <location filename="startide.py" line="760"/>
        <source>WaitInDig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1717"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1735"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="900"/>
        <source>Condition</source>
        <translation>Bedingung</translation>
    </message>
    <message>
        <location filename="startide.py" line="820"/>
        <source>Timeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1696"/>
        <source>TOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2801"/>
        <source>IfInDig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="936"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1863"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="startide.py" line="1024"/>
        <source>Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1541"/>
        <source>Direction</source>
        <translation>Drehrichtung</translation>
    </message>
    <message>
        <location filename="startide.py" line="1547"/>
        <source>right</source>
        <translation>rechts</translation>
    </message>
    <message>
        <location filename="startide.py" line="1547"/>
        <source>left</source>
        <translation>links</translation>
    </message>
    <message>
        <location filename="startide.py" line="1547"/>
        <source>stop</source>
        <translation>stop</translation>
    </message>
    <message>
        <location filename="startide.py" line="1142"/>
        <source>MotorP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1404"/>
        <source>End Sw.</source>
        <translation>Endschalter</translation>
    </message>
    <message>
        <location filename="startide.py" line="1242"/>
        <source>Pulse Inp.</source>
        <translation>Impulseingang</translation>
    </message>
    <message>
        <location filename="startide.py" line="1628"/>
        <source>Pulses</source>
        <translation>Impulse</translation>
    </message>
    <message>
        <location filename="startide.py" line="1322"/>
        <source>MotorE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1481"/>
        <source>MotorES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1563"/>
        <source>Sync to</source>
        <translation>Sync mit</translation>
    </message>
    <message>
        <location filename="startide.py" line="2846"/>
        <source>LoopTo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1656"/>
        <source>Loop target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="1672"/>
        <source>Count</source>
        <translation>Anzahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="2215"/>
        <source>Project</source>
        <translation type="unfinished">Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="2880"/>
        <source>Module</source>
        <translation type="unfinished">Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="2848"/>
        <source>No Tags defined!</source>
        <translation>Keine Tags definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="2894"/>
        <source>Okay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2813"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2816"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2835"/>
        <source>Jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2899"/>
        <source>Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2864"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2899"/>
        <source>Call</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2891"/>
        <source>No Modules defined!</source>
        <translation>Keine Module definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="2905"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2912"/>
        <source>Message</source>
        <translation type="unfinished">Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="2912"/>
        <source>BtnTxt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1703"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>Inp. type</source>
        <translation>Eing.-Art</translation>
    </message>
    <message>
        <location filename="startide.py" line="1766"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="startide.py" line="1833"/>
        <source>switch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1833"/>
        <source>voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1833"/>
        <source>resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1833"/>
        <source>distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1833"/>
        <source>counter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>exec</name>
    <message>
        <location filename="startide.py" line="205"/>
        <source>TXT not found!
Program terminated
</source>
        <translation>TXT nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="208"/>
        <source>RoboIF not found!
Program terminated
</source>
        <translation>RoboInterface nicht gefunden!
Programm abgebochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="214"/>
        <source>MEnd found with-
out Module!
Program terminated
</source>
        <translation>MEnd ohne Modul!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="217"/>
        <source>MEnd missing!
Program terminated
</source>
        <translation>MEnd fehlt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="220"/>
        <source>TXT M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>TXT M1 und O1/O2
gleichtzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="223"/>
        <source>TXT M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>TXT M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="226"/>
        <source>TXT M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>TXT M3 und O5/O6
gleichzeitig belegt.
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="229"/>
        <source>TXT M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="232"/>
        <source>RIF M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>RIF M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="235"/>
        <source>RIF M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>RIF M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="238"/>
        <source>RIF M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>RIF M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="241"/>
        <source>RIF M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="260"/>
        <source>M3 and M4 not available
on Robo LT!
Program terminated
</source>
        <translation>M3 und M4 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="263"/>
        <source>O5 to O8 not available
on Robo LT!
Program terminated
</source>
        <translation>O5 bis O8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="266"/>
        <source>I4 to I8 not available
on Robo LT!
Program terminated
</source>
        <translation>I4 bis I8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="2502"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="211"/>
        <source>ftduino not found!
Program terminated
</source>
        <translation>ftduino nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="244"/>
        <source>FTD M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>FTD M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="247"/>
        <source>FTD M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>FTD M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="250"/>
        <source>FTD M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>FTD M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="253"/>
        <source>FTD M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
</context>
<context>
    <name>m_about</name>
    <message>
        <location filename="startide.py" line="2081"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="2083"/>
        <source>A tiny IDE to control Robo Family Interfaces and TXT Hardware.</source>
        <translation>Eine Mini-IDE zum Steuern von Robo Interfaces und TXT Hardware.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>The manual is available in the webinterface under &apos;Get more app info&apos;.</source>
        <translation type="obsolete">Das Handbuch liegt im Webinterface unter &apos;Get more app info&apos;. </translation>
    </message>
    <message>
        <location filename="startide.py" line="2088"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2083"/>
        <source>The manual is available in the TXT startIDE webinterface under &apos;Get more app info&apos;.</source>
        <translation>Das Handbuch ist im TXT startIDE webinterface unter &apos;Get more app info&apos; verfügbar.</translation>
    </message>
    <message>
        <location filename="startide.py" line="2092"/>
        <source>News</source>
        <translation>News</translation>
    </message>
</context>
<context>
    <name>m_interfaces</name>
    <message>
        <location filename="startide.py" line="2404"/>
        <source>No Robo device</source>
        <translation>Kein Robo Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="2407"/>
        <source>No TXT device</source>
        <translation>Kein TXT Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="2408"/>
        <source>TXT found</source>
        <translation>TXT gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="2413"/>
        <source>Hardware found:</source>
        <translation>Gefundene Hardware:</translation>
    </message>
    <message>
        <location filename="startide.py" line="2415"/>
        <source>Interfaces</source>
        <translation>Interfaces</translation>
    </message>
    <message>
        <location filename="startide.py" line="2420"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2410"/>
        <source>No ftduino device</source>
        <translation>Kein ftduino</translation>
    </message>
    <message>
        <location filename="startide.py" line="2411"/>
        <source>found</source>
        <translation>gefunden</translation>
    </message>
</context>
<context>
    <name>m_modules</name>
    <message>
        <location filename="startide.py" line="2264"/>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="2329"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="2379"/>
        <source>No saved modules found.</source>
        <translation>Keine gespeicherten Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="2381"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2319"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="2312"/>
        <source>MEnd found with-
out Module!
Please fix before export!
</source>
        <translation>MEnd ohne Modul gefunden.
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="2321"/>
        <source>MEnd missing!
Please fix before export!
</source>
        <translation>MEnd fehlt!
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="2348"/>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="2333"/>
        <source>No modules found.</source>
        <translation>Keine Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="2350"/>
        <source>A module file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Modul mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="2395"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="2392"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="2387"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="2389"/>
        <source>Do you really want to permanently delete this module?</source>
        <translation>Soll das Modul wirklich für immer gelöscht werden?</translation>
    </message>
</context>
<context>
    <name>m_project</name>
    <message>
        <location filename="startide.py" line="2104"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="2124"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <location filename="startide.py" line="2160"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="startide.py" line="2190"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="startide.py" line="2255"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="2146"/>
        <source>Current project was not saved. Do you want to discard it?</source>
        <translation>Projekt ist nicht gespeichert. Soll es gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="2235"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="2232"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="2219"/>
        <source>No saved projects found.</source>
        <translation>Keine gespeicherten Projekte.</translation>
    </message>
    <message>
        <location filename="startide.py" line="2221"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2181"/>
        <source>Enter project file name:</source>
        <translation>Projektnamen eingeben:</translation>
    </message>
    <message>
        <location filename="startide.py" line="2192"/>
        <source>A file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Projekt mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="2229"/>
        <source>Do you really want to permanently delete this project?</source>
        <translation>Soll das Projekt wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="2242"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="2253"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="startide.py" line="2254"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="startide.py" line="2524"/>
        <source>Start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2497"/>
        <source>Close log</source>
        <translation>Schließe Log</translation>
    </message>
    <message>
        <location filename="startide.py" line="2526"/>
        <source>Stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2008"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="2012"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
</context>
<context>
    <name>mmain</name>
    <message>
        <location filename="startide.py" line="1927"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="1932"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="1937"/>
        <source>Interfaces</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1942"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
</context>
</TS>
