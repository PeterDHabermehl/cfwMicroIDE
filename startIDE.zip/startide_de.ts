<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>addcodeline</name>
    <message>
        <location filename="startide.py" line="6932"/>
        <source>New cmd:</source>
        <translation>Neuer Befehl:</translation>
    </message>
    <message>
        <location filename="startide.py" line="6949"/>
        <source>Inputs</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="6975"/>
        <source>Outputs</source>
        <translation>Ausgänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="7047"/>
        <source>Controls</source>
        <translation>Steuerung</translation>
    </message>
    <message>
        <location filename="startide.py" line="7094"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="7112"/>
        <source>Interaction</source>
        <translation>Interaktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="6962"/>
        <source>WaitForInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6964"/>
        <source>IfInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6991"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6992"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6993"/>
        <source>MotorPulsew.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6994"/>
        <source>MotorEnc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6995"/>
        <source>MotorEncSync</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7061"/>
        <source># comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7062"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7063"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7064"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7079"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7090"/>
        <source>Stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7106"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7108"/>
        <source>Return</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7109"/>
        <source>Module</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7110"/>
        <source>MEnd</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7113"/>
        <source>Interact</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7125"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7157"/>
        <source>Clear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7127"/>
        <source>Message</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7017"/>
        <source>Variables</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="startide.py" line="6966"/>
        <source>WaitForInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6968"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6970"/>
        <source>QueryInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7015"/>
        <source>Init</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7016"/>
        <source>From...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7042"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7043"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7044"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7034"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7035"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7036"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7037"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7041"/>
        <source>Shelf</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7066"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7080"/>
        <source>TimerQuery</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7082"/>
        <source>TimerClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7084"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7086"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7088"/>
        <source>QueryNow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7107"/>
        <source>CallExt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7325"/>
        <source>Logfile</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7336"/>
        <source>Log On</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7337"/>
        <source>Log Off</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7339"/>
        <source>Log Clear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6972"/>
        <source>CounterClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7038"/>
        <source>FromPoly</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7039"/>
        <source>FromSys</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7091"/>
        <source>RIFShift</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7130"/>
        <source>Graphics</source>
        <translation>Grafik</translation>
    </message>
    <message>
        <location filename="startide.py" line="7143"/>
        <source>Canvas</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7162"/>
        <source>Pen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7164"/>
        <source>Color</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7163"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="startide.py" line="7165"/>
        <source>VarToText</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7155"/>
        <source>Show</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7156"/>
        <source>Hide</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7158"/>
        <source>Update</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7159"/>
        <source>Origin</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7160"/>
        <source>Log</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7338"/>
        <source>Log Silent</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>color</name>
    <message>
        <location filename="startide.py" line="5753"/>
        <source>red</source>
        <translation>Rot</translation>
    </message>
    <message>
        <location filename="startide.py" line="5757"/>
        <source>green</source>
        <translation>Grün</translation>
    </message>
    <message>
        <location filename="startide.py" line="5761"/>
        <source>blue</source>
        <translation>Blau</translation>
    </message>
    <message>
        <location filename="startide.py" line="5765"/>
        <source>yellow</source>
        <translation>Gelb</translation>
    </message>
    <message>
        <location filename="startide.py" line="5769"/>
        <source>cyan</source>
        <translation>Türkis</translation>
    </message>
    <message>
        <location filename="startide.py" line="5773"/>
        <source>magenta</source>
        <translation>Violett</translation>
    </message>
    <message>
        <location filename="startide.py" line="5777"/>
        <source>cfw-blue</source>
        <translation>cfw-Blau</translation>
    </message>
    <message>
        <location filename="startide.py" line="5781"/>
        <source>white</source>
        <translation>Weiß</translation>
    </message>
    <message>
        <location filename="startide.py" line="5785"/>
        <source>grey</source>
        <translation>Grau</translation>
    </message>
    <message>
        <location filename="startide.py" line="5789"/>
        <source>black</source>
        <translation>Schwarz</translation>
    </message>
    <message>
        <location filename="startide.py" line="5750"/>
        <source>Colors</source>
        <translation>Farben</translation>
    </message>
</context>
<context>
    <name>ecl</name>
    <message>
        <location filename="startide.py" line="2006"/>
        <source>Condition</source>
        <translation>Bedingung</translation>
    </message>
    <message>
        <location filename="startide.py" line="6010"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="startide.py" line="2883"/>
        <source>Direction</source>
        <translation>Drehrichtung</translation>
    </message>
    <message>
        <location filename="startide.py" line="2889"/>
        <source>right</source>
        <translation>rechts</translation>
    </message>
    <message>
        <location filename="startide.py" line="2889"/>
        <source>left</source>
        <translation>links</translation>
    </message>
    <message>
        <location filename="startide.py" line="2889"/>
        <source>stop</source>
        <translation>stop</translation>
    </message>
    <message>
        <location filename="startide.py" line="2695"/>
        <source>End Sw.</source>
        <translation>Endschalter</translation>
    </message>
    <message>
        <location filename="startide.py" line="2483"/>
        <source>Pulse Inp.</source>
        <translation>Impulseingang</translation>
    </message>
    <message>
        <location filename="startide.py" line="3017"/>
        <source>Pulses</source>
        <translation>Impulse</translation>
    </message>
    <message>
        <location filename="startide.py" line="2905"/>
        <source>Sync to</source>
        <translation>Sync mit</translation>
    </message>
    <message>
        <location filename="startide.py" line="3048"/>
        <source>Loop target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="3161"/>
        <source>Count</source>
        <translation>Anzahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="6395"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="7738"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="7707"/>
        <source>No Tags defined!</source>
        <translation>Keine Tags definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="7752"/>
        <source>No Modules defined!</source>
        <translation>Keine Module definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="7774"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="4274"/>
        <source>Inp. type</source>
        <translation>Eing.-Art</translation>
    </message>
    <message>
        <location filename="startide.py" line="5961"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="startide.py" line="1837"/>
        <source>WaitInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4237"/>
        <source>Device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4255"/>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3995"/>
        <source>Timeout</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1946"/>
        <source>TOut</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7465"/>
        <source>IfInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2109"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2228"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2377"/>
        <source>MotorP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2607"/>
        <source>MotorE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2817"/>
        <source>MotorES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7666"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4348"/>
        <source>switch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4348"/>
        <source>voltage</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4348"/>
        <source>resistance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4348"/>
        <source>distance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7755"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7633"/>
        <source>Comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7636"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7655"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7655"/>
        <source>Target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="7687"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7750"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7767"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7774"/>
        <source>BtnTxt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="116"/>
        <source>Variables</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="startide.py" line="103"/>
        <source>No Variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="116"/>
        <source>Select variable</source>
        <translation>Variable wählen</translation>
    </message>
    <message>
        <location filename="startide.py" line="3866"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="3216"/>
        <source>QueryIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3386"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4561"/>
        <source>Operator</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3632"/>
        <source>WaitIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7705"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7621"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7723"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4090"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4058"/>
        <source>Target module</source>
        <translation>Zielmodul</translation>
    </message>
    <message>
        <location filename="startide.py" line="7587"/>
        <source>Variable</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4119"/>
        <source>Variable name</source>
        <translation>Variablenname</translation>
    </message>
    <message>
        <location filename="startide.py" line="4189"/>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7498"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7608"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4544"/>
        <source>First Operand</source>
        <translation>Erster Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4578"/>
        <source>Second Operand</source>
        <translation>Zweiter Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4594"/>
        <source>Target variable</source>
        <translation>Zielvariable</translation>
    </message>
    <message>
        <location filename="startide.py" line="5484"/>
        <source>1st Op.</source>
        <translation>1. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="5507"/>
        <source>2nd Op.</source>
        <translation>2. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="7550"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5131"/>
        <source>Min value</source>
        <translation>Minimum</translation>
    </message>
    <message>
        <location filename="startide.py" line="5148"/>
        <source>Max value</source>
        <translation>Maximum</translation>
    </message>
    <message>
        <location filename="startide.py" line="5219"/>
        <source>Min</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5251"/>
        <source>Max</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5094"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7563"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5270"/>
        <source>Buttons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5300"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="5307"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="5366"/>
        <source>Btn. Text</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7482"/>
        <source>IfIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7587"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7623"/>
        <source>No variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="2049"/>
        <source>CounterClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4348"/>
        <source>counter</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7511"/>
        <source>FromPoly</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4770"/>
        <source>Input:</source>
        <translation>Eingangsvariable:</translation>
    </message>
    <message>
        <location filename="startide.py" line="4924"/>
        <source>Target:</source>
        <translation>Zielvariable:</translation>
    </message>
    <message>
        <location filename="startide.py" line="4812"/>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4821"/>
        <source>B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4830"/>
        <source>C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4839"/>
        <source>D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4881"/>
        <source>Input</source>
        <translation>Eingangsvariable</translation>
    </message>
    <message>
        <location filename="startide.py" line="7524"/>
        <source>FromSys</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4905"/>
        <source>Data:</source>
        <translation>Daten:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5379"/>
        <source>Pen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5397"/>
        <source>Operation</source>
        <translation>Funktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="5413"/>
        <source>x position</source>
        <translation>x-Position</translation>
    </message>
    <message>
        <location filename="startide.py" line="5430"/>
        <source>y position</source>
        <translation>y-Position</translation>
    </message>
    <message>
        <location filename="startide.py" line="5516"/>
        <source>Color</source>
        <translation>Farbe</translation>
    </message>
    <message>
        <location filename="startide.py" line="5545"/>
        <source>Red:</source>
        <translation>Rot:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5564"/>
        <source>Green:</source>
        <translation>Grün:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5583"/>
        <source>Blue:</source>
        <translation>Blau:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5618"/>
        <source>Presets</source>
        <translation>Vorgaben</translation>
    </message>
    <message>
        <location filename="startide.py" line="5670"/>
        <source>Red</source>
        <translation>Rot</translation>
    </message>
    <message>
        <location filename="startide.py" line="5694"/>
        <source>Green</source>
        <translation>Grün</translation>
    </message>
    <message>
        <location filename="startide.py" line="5719"/>
        <source>Blue</source>
        <translation>Blau</translation>
    </message>
    <message>
        <location filename="startide.py" line="5929"/>
        <source>Font type</source>
        <translation>Schrifttyp</translation>
    </message>
    <message>
        <location filename="startide.py" line="5946"/>
        <source>Font size</source>
        <translation>Schriftgröße</translation>
    </message>
    <message>
        <location filename="startide.py" line="5909"/>
        <source>VarToText</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7782"/>
        <source>RIFShift</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>exec</name>
    <message>
        <location filename="startide.py" line="368"/>
        <source>TXT not found!
Program terminated
</source>
        <translation>TXT nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="371"/>
        <source>RoboIF not found!
Program terminated
</source>
        <translation>RoboInterface nicht gefunden!
Programm abgebochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="389"/>
        <source>MEnd found with-
out Module!
Program terminated
</source>
        <translation>MEnd ohne Modul!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="392"/>
        <source>MEnd missing!
Program terminated
</source>
        <translation>MEnd fehlt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="395"/>
        <source>TXT M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>TXT M1 und O1/O2
gleichtzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="398"/>
        <source>TXT M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>TXT M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="401"/>
        <source>TXT M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>TXT M3 und O5/O6
gleichzeitig belegt.
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="229"/>
        <source>TXT M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="407"/>
        <source>RIF M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>RIF M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="410"/>
        <source>RIF M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>RIF M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="413"/>
        <source>RIF M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>RIF M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="241"/>
        <source>RIF M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="435"/>
        <source>M3 and M4 not available
on Robo LT!
Program terminated
</source>
        <translation>M3 und M4 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="438"/>
        <source>O5 to O8 not available
on Robo LT!
Program terminated
</source>
        <translation>O5 bis O8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="441"/>
        <source>I4 to I8 not available
on Robo LT!
Program terminated
</source>
        <translation>I4 bis I8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="6867"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="374"/>
        <source>ftduino not found!
Program terminated
</source>
        <translation>ftduino nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="419"/>
        <source>FTD M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>FTD M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="422"/>
        <source>FTD M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>FTD M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="425"/>
        <source>FTD M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>FTD M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="253"/>
        <source>FTD M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="404"/>
        <source>TXT M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="416"/>
        <source>RIF M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="428"/>
        <source>FTD M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="380"/>
        <source>TXT analog I</source>
        <translation>TXT Eingang I</translation>
    </message>
    <message>
        <location filename="startide.py" line="383"/>
        <source>
types inconsistent!
Program terminated
</source>
        <translation>Typen inkonsistent!
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="377"/>
        <source>External Module</source>
        <translation>Externes Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="377"/>
        <source>not found.
Program terminated
</source>
        <translation>nicht gefunden.
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="383"/>
        <source>FTD analog I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="386"/>
        <source>FTD counter C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="386"/>
        <source>
counter/distance mismatch!
Program terminated
</source>
        <translation>
counter/distance Unstimmigkeit!
Programm abgebrochen
</translation>
    </message>
</context>
<context>
    <name>m_about</name>
    <message>
        <location filename="startide.py" line="6261"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="6263"/>
        <source>A tiny IDE to control Robo Family Interfaces and TXT Hardware.</source>
        <translation>Eine Mini-IDE zum Steuern von Robo Interfaces und TXT Hardware.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>The manual is available in the webinterface under &apos;Get more app info&apos;.</source>
        <translation type="obsolete">Das Handbuch liegt im Webinterface unter &apos;Get more app info&apos;. </translation>
    </message>
    <message>
        <location filename="startide.py" line="6263"/>
        <source>The manual is available in the TXT startIDE webinterface under &apos;Get more app info&apos;.</source>
        <translation>Das Handbuch ist im TXT startIDE webinterface unter &apos;Get more app info&apos; verfügbar.</translation>
    </message>
    <message>
        <location filename="startide.py" line="6272"/>
        <source>News</source>
        <translation>News</translation>
    </message>
    <message>
        <location filename="startide.py" line="6268"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_interfaces</name>
    <message>
        <location filename="startide.py" line="6585"/>
        <source>No Robo device</source>
        <translation>Kein Robo Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="6588"/>
        <source>No TXT device</source>
        <translation>Kein TXT Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="6589"/>
        <source>TXT found</source>
        <translation>TXT gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="6594"/>
        <source>Hardware found:</source>
        <translation>Gefundene Hardware:</translation>
    </message>
    <message>
        <location filename="startide.py" line="6596"/>
        <source>Interfaces</source>
        <translation>Interfaces</translation>
    </message>
    <message>
        <location filename="startide.py" line="6591"/>
        <source>No ftduino device</source>
        <translation>Kein ftduino</translation>
    </message>
    <message>
        <location filename="startide.py" line="6592"/>
        <source>found</source>
        <translation>gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="6601"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6617"/>
        <source>Enable IIF</source>
        <translation>IIf aktivieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="6608"/>
        <source>Enabling IIF with any device other than an Intelligent Interface connected to &apos;/dev/ttyUSB0&apos; will crash startIDE.</source>
        <translation>Aktivieren des IIf ohne angeschlossenes Interface an /dev/ttyUSB0 führt zum Programmabsturz.</translation>
    </message>
    <message>
        <location filename="startide.py" line="6614"/>
        <source>Cancel</source>
        <translation>Abbrechen
</translation>
    </message>
</context>
<context>
    <name>m_modules</name>
    <message>
        <location filename="startide.py" line="6444"/>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="6509"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="6559"/>
        <source>No saved modules found.</source>
        <translation>Keine gespeicherten Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="6499"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="6492"/>
        <source>MEnd found with-
out Module!
Please fix before export!
</source>
        <translation>MEnd ohne Modul gefunden.
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="6501"/>
        <source>MEnd missing!
Please fix before export!
</source>
        <translation>MEnd fehlt!
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="6528"/>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="6513"/>
        <source>No modules found.</source>
        <translation>Keine Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="6530"/>
        <source>A module file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Modul mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="6575"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="6572"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="6567"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="6569"/>
        <source>Do you really want to permanently delete this module?</source>
        <translation>Soll das Modul wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="6561"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_project</name>
    <message>
        <location filename="startide.py" line="6284"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="6304"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <location filename="startide.py" line="6340"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="startide.py" line="6370"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="startide.py" line="6435"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="6326"/>
        <source>Current project was not saved. Do you want to discard it?</source>
        <translation>Projekt ist nicht gespeichert. Soll es gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="6415"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="6412"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="6399"/>
        <source>No saved projects found.</source>
        <translation>Keine gespeicherten Projekte.</translation>
    </message>
    <message>
        <location filename="startide.py" line="6361"/>
        <source>Enter project file name:</source>
        <translation>Projektnamen eingeben:</translation>
    </message>
    <message>
        <location filename="startide.py" line="6372"/>
        <source>A file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Projekt mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="6409"/>
        <source>Do you really want to permanently delete this project?</source>
        <translation>Soll das Projekt wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="6422"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="6433"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="startide.py" line="6434"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="startide.py" line="6401"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="startide.py" line="6711"/>
        <source>Close log</source>
        <translation>Schließe Log</translation>
    </message>
    <message>
        <location filename="startide.py" line="6175"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="6179"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="6919"/>
        <source>Start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6921"/>
        <source>Stop</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>mmain</name>
    <message>
        <location filename="startide.py" line="6094"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="6099"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="6109"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="6104"/>
        <source>Interfaces</source>
        <translation></translation>
    </message>
</context>
</TS>
