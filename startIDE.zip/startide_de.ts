<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>addcodeline</name>
    <message>
        <location filename="startide.py" line="5535"/>
        <source>New cmd:</source>
        <translation>Neuer Befehl:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5552"/>
        <source>Inputs</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="5575"/>
        <source>Outputs</source>
        <translation>Ausgänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="5662"/>
        <source>Controls</source>
        <translation>Steuerung</translation>
    </message>
    <message>
        <location filename="startide.py" line="5689"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5707"/>
        <source>Interaction</source>
        <translation>Interaktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="5564"/>
        <source>WaitForInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5566"/>
        <source>IfInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5591"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5592"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5593"/>
        <source>MotorPulsew.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5594"/>
        <source>MotorEnc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5595"/>
        <source>MotorEncSync</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5657"/>
        <source># comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5658"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5659"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5660"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5675"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5686"/>
        <source>Stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5701"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5703"/>
        <source>Return</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5704"/>
        <source>Module</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5705"/>
        <source>MEnd</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5708"/>
        <source>Interact</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5719"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5720"/>
        <source>Clear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5721"/>
        <source>Message</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5618"/>
        <source>Variables</source>
        <translation>Variablen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5568"/>
        <source>WaitForInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5570"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5572"/>
        <source>QueryInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5616"/>
        <source>Init</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5617"/>
        <source>From...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5639"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5640"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5641"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5633"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5634"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5635"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5636"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5638"/>
        <source>Shelf</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5661"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5676"/>
        <source>TimerQuery</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5678"/>
        <source>TimerClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5680"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5682"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5684"/>
        <source>QueryNow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5702"/>
        <source>CallExt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5843"/>
        <source>Logfile</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5853"/>
        <source>Log On</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5854"/>
        <source>Log Off</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5855"/>
        <source>Log Clear</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ecl</name>
    <message>
        <location filename="startide.py" line="1796"/>
        <source>Condition</source>
        <translation>Bedingung</translation>
    </message>
    <message>
        <location filename="startide.py" line="4244"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="startide.py" line="2611"/>
        <source>Direction</source>
        <translation>Drehrichtung</translation>
    </message>
    <message>
        <location filename="startide.py" line="2617"/>
        <source>right</source>
        <translation>rechts</translation>
    </message>
    <message>
        <location filename="startide.py" line="2617"/>
        <source>left</source>
        <translation>links</translation>
    </message>
    <message>
        <location filename="startide.py" line="2617"/>
        <source>stop</source>
        <translation>stop</translation>
    </message>
    <message>
        <location filename="startide.py" line="2423"/>
        <source>End Sw.</source>
        <translation>Endschalter</translation>
    </message>
    <message>
        <location filename="startide.py" line="2211"/>
        <source>Pulse Inp.</source>
        <translation>Impulseingang</translation>
    </message>
    <message>
        <location filename="startide.py" line="2745"/>
        <source>Pulses</source>
        <translation>Impulse</translation>
    </message>
    <message>
        <location filename="startide.py" line="2633"/>
        <source>Sync to</source>
        <translation>Sync mit</translation>
    </message>
    <message>
        <location filename="startide.py" line="2776"/>
        <source>Loop target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="2889"/>
        <source>Count</source>
        <translation>Anzahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="5180"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="6214"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="6183"/>
        <source>No Tags defined!</source>
        <translation>Keine Tags definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="6228"/>
        <source>No Modules defined!</source>
        <translation>Keine Module definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="6250"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="4001"/>
        <source>Inp. type</source>
        <translation>Eing.-Art</translation>
    </message>
    <message>
        <location filename="startide.py" line="3007"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="startide.py" line="1627"/>
        <source>WaitInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3964"/>
        <source>Device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3982"/>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3722"/>
        <source>Timeout</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1736"/>
        <source>TOut</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5967"/>
        <source>IfInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1837"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1956"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2105"/>
        <source>MotorP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2335"/>
        <source>MotorE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2545"/>
        <source>MotorES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6142"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4075"/>
        <source>switch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4075"/>
        <source>voltage</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4075"/>
        <source>resistance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4075"/>
        <source>distance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6231"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6109"/>
        <source>Comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6112"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6131"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6131"/>
        <source>Target</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6163"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6226"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6243"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6250"/>
        <source>BtnTxt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="99"/>
        <source>Variables</source>
        <translation>Variablen</translation>
    </message>
    <message>
        <location filename="startide.py" line="86"/>
        <source>No Variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="99"/>
        <source>Select variable</source>
        <translation>Variable wählen</translation>
    </message>
    <message>
        <location filename="startide.py" line="3593"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="2944"/>
        <source>QueryIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3114"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4288"/>
        <source>Operator</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3359"/>
        <source>WaitIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6181"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6097"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6199"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3817"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3785"/>
        <source>Target module</source>
        <translation>Zielmodul</translation>
    </message>
    <message>
        <location filename="startide.py" line="6063"/>
        <source>Variable</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3846"/>
        <source>Variable name</source>
        <translation>Variablenname</translation>
    </message>
    <message>
        <location filename="startide.py" line="3916"/>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3948"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6084"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4271"/>
        <source>First Operand</source>
        <translation>Erster Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4305"/>
        <source>Second Operand</source>
        <translation>Zweiter Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4321"/>
        <source>Target variable</source>
        <translation>Zielvariable</translation>
    </message>
    <message>
        <location filename="startide.py" line="4374"/>
        <source>1st Op.</source>
        <translation>1. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4397"/>
        <source>2nd Op.</source>
        <translation>2. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="6026"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4581"/>
        <source>Min value</source>
        <translation>Minimum</translation>
    </message>
    <message>
        <location filename="startide.py" line="4598"/>
        <source>Max value</source>
        <translation>Maximum</translation>
    </message>
    <message>
        <location filename="startide.py" line="4669"/>
        <source>Min</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4701"/>
        <source>Max</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4544"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6039"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4720"/>
        <source>Buttons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4750"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="4757"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="4816"/>
        <source>Btn. Text</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5984"/>
        <source>IfIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6063"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6099"/>
        <source>No variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
</context>
<context>
    <name>exec</name>
    <message>
        <location filename="startide.py" line="339"/>
        <source>TXT not found!
Program terminated
</source>
        <translation>TXT nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="342"/>
        <source>RoboIF not found!
Program terminated
</source>
        <translation>RoboInterface nicht gefunden!
Programm abgebochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="360"/>
        <source>MEnd found with-
out Module!
Program terminated
</source>
        <translation>MEnd ohne Modul!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="363"/>
        <source>MEnd missing!
Program terminated
</source>
        <translation>MEnd fehlt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="366"/>
        <source>TXT M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>TXT M1 und O1/O2
gleichtzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="369"/>
        <source>TXT M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>TXT M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="372"/>
        <source>TXT M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>TXT M3 und O5/O6
gleichzeitig belegt.
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="229"/>
        <source>TXT M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="378"/>
        <source>RIF M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>RIF M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="381"/>
        <source>RIF M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>RIF M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="384"/>
        <source>RIF M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>RIF M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="241"/>
        <source>RIF M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="406"/>
        <source>M3 and M4 not available
on Robo LT!
Program terminated
</source>
        <translation>M3 und M4 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="409"/>
        <source>O5 to O8 not available
on Robo LT!
Program terminated
</source>
        <translation>O5 bis O8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="412"/>
        <source>I4 to I8 not available
on Robo LT!
Program terminated
</source>
        <translation>I4 bis I8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5470"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="345"/>
        <source>ftduino not found!
Program terminated
</source>
        <translation>ftduino nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="390"/>
        <source>FTD M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>FTD M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="393"/>
        <source>FTD M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>FTD M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="396"/>
        <source>FTD M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>FTD M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="253"/>
        <source>FTD M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="375"/>
        <source>TXT M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="387"/>
        <source>RIF M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="399"/>
        <source>FTD M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="351"/>
        <source>TXT analog I</source>
        <translation>TXT Eingang I</translation>
    </message>
    <message>
        <location filename="startide.py" line="354"/>
        <source>
types inconsistent!
Program terminated
</source>
        <translation>Typen inkonsistent!
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="348"/>
        <source>External Module</source>
        <translation>Externes Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="348"/>
        <source>not found.
Program terminated
</source>
        <translation>nicht gefunden.
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="354"/>
        <source>FTD analog I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="357"/>
        <source>FTD counter C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="357"/>
        <source>
counter/distance mismatch!
Program terminated
</source>
        <translation>
counter/distance Unstimmigkeit!
Programm abgebrochen
</translation>
    </message>
</context>
<context>
    <name>m_about</name>
    <message>
        <location filename="startide.py" line="5046"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="5048"/>
        <source>A tiny IDE to control Robo Family Interfaces and TXT Hardware.</source>
        <translation>Eine Mini-IDE zum Steuern von Robo Interfaces und TXT Hardware.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>The manual is available in the webinterface under &apos;Get more app info&apos;.</source>
        <translation type="obsolete">Das Handbuch liegt im Webinterface unter &apos;Get more app info&apos;. </translation>
    </message>
    <message>
        <location filename="startide.py" line="5048"/>
        <source>The manual is available in the TXT startIDE webinterface under &apos;Get more app info&apos;.</source>
        <translation>Das Handbuch ist im TXT startIDE webinterface unter &apos;Get more app info&apos; verfügbar.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5057"/>
        <source>News</source>
        <translation>News</translation>
    </message>
    <message>
        <location filename="startide.py" line="5053"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_interfaces</name>
    <message>
        <location filename="startide.py" line="5369"/>
        <source>No Robo device</source>
        <translation>Kein Robo Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="5372"/>
        <source>No TXT device</source>
        <translation>Kein TXT Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="5373"/>
        <source>TXT found</source>
        <translation>TXT gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5378"/>
        <source>Hardware found:</source>
        <translation>Gefundene Hardware:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5380"/>
        <source>Interfaces</source>
        <translation>Interfaces</translation>
    </message>
    <message>
        <location filename="startide.py" line="5375"/>
        <source>No ftduino device</source>
        <translation>Kein ftduino</translation>
    </message>
    <message>
        <location filename="startide.py" line="5376"/>
        <source>found</source>
        <translation>gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5385"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_modules</name>
    <message>
        <location filename="startide.py" line="5229"/>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="5294"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="5344"/>
        <source>No saved modules found.</source>
        <translation>Keine gespeicherten Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5284"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5277"/>
        <source>MEnd found with-
out Module!
Please fix before export!
</source>
        <translation>MEnd ohne Modul gefunden.
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="5286"/>
        <source>MEnd missing!
Please fix before export!
</source>
        <translation>MEnd fehlt!
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="5313"/>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="5298"/>
        <source>No modules found.</source>
        <translation>Keine Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5315"/>
        <source>A module file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Modul mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5360"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="5357"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="5352"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5354"/>
        <source>Do you really want to permanently delete this module?</source>
        <translation>Soll das Modul wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5346"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_project</name>
    <message>
        <location filename="startide.py" line="5069"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="5089"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <location filename="startide.py" line="5125"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5155"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="startide.py" line="5220"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5111"/>
        <source>Current project was not saved. Do you want to discard it?</source>
        <translation>Projekt ist nicht gespeichert. Soll es gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5200"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="5197"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="5184"/>
        <source>No saved projects found.</source>
        <translation>Keine gespeicherten Projekte.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5146"/>
        <source>Enter project file name:</source>
        <translation>Projektnamen eingeben:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5157"/>
        <source>A file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Projekt mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5194"/>
        <source>Do you really want to permanently delete this project?</source>
        <translation>Soll das Projekt wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5207"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5218"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="startide.py" line="5219"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="startide.py" line="5186"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="startide.py" line="5465"/>
        <source>Close log</source>
        <translation>Schließe Log</translation>
    </message>
    <message>
        <location filename="startide.py" line="4967"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="4971"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="5522"/>
        <source>Start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5524"/>
        <source>Stop</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>mmain</name>
    <message>
        <location filename="startide.py" line="4886"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="4891"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="4901"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="4896"/>
        <source>Interfaces</source>
        <translation></translation>
    </message>
</context>
</TS>
