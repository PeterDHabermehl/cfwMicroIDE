<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>addcodeline</name>
    <message>
        <location filename="startide.py" line="7892"/>
        <source>New cmd:</source>
        <translation>Neuer Befehl:</translation>
    </message>
    <message>
        <location filename="startide.py" line="7909"/>
        <source>Inputs</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="7935"/>
        <source>Outputs</source>
        <translation>Ausgänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="8032"/>
        <source>Controls</source>
        <translation>Steuerung</translation>
    </message>
    <message>
        <location filename="startide.py" line="8079"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="8097"/>
        <source>Interaction</source>
        <translation>Interaktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="7922"/>
        <source>WaitForInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7924"/>
        <source>IfInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7951"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7952"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7953"/>
        <source>MotorPulsew.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7954"/>
        <source>MotorEnc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7955"/>
        <source>MotorEncSync</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8046"/>
        <source># comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8047"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8048"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8049"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8064"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8075"/>
        <source>Stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8091"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8093"/>
        <source>Return</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8094"/>
        <source>Module</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8095"/>
        <source>MEnd</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8098"/>
        <source>Interact</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8111"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8143"/>
        <source>Clear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8113"/>
        <source>Message</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7958"/>
        <source>Variables</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="startide.py" line="7926"/>
        <source>WaitForInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7928"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7930"/>
        <source>QueryInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7976"/>
        <source>Init</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7978"/>
        <source>From...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8027"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8028"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8029"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7995"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7996"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7997"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7998"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8051"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8065"/>
        <source>TimerQuery</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8067"/>
        <source>TimerClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8069"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8071"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8073"/>
        <source>QueryNow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8092"/>
        <source>CallExt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8335"/>
        <source>Logfile</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8346"/>
        <source>Log On</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8347"/>
        <source>Log Off</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8349"/>
        <source>Log Clear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7932"/>
        <source>CounterClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7999"/>
        <source>FromPoly</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8000"/>
        <source>FromSys</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8076"/>
        <source>RIFShift</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8116"/>
        <source>Graphics</source>
        <translation>Grafik</translation>
    </message>
    <message>
        <location filename="startide.py" line="8129"/>
        <source>Canvas</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8148"/>
        <source>Pen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8150"/>
        <source>Color</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8149"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="startide.py" line="8151"/>
        <source>VarToText</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8141"/>
        <source>Show</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8142"/>
        <source>Hide</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8144"/>
        <source>Update</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8145"/>
        <source>Origin</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8146"/>
        <source>Log</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8348"/>
        <source>Log Silent</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8003"/>
        <source>Arrays</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8020"/>
        <source>ArrayInit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8021"/>
        <source>Array</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8022"/>
        <source>ArrayStat</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8023"/>
        <source>QueryArray</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8024"/>
        <source>ArrayLoad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8025"/>
        <source>ArraySave</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8153"/>
        <source>Touch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8163"/>
        <source>WaitForTouch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8164"/>
        <source>WaitForRelease</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8165"/>
        <source>IfTouchArea</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>color</name>
    <message>
        <location filename="startide.py" line="6292"/>
        <source>red</source>
        <translation>Rot</translation>
    </message>
    <message>
        <location filename="startide.py" line="6296"/>
        <source>green</source>
        <translation>Grün</translation>
    </message>
    <message>
        <location filename="startide.py" line="6300"/>
        <source>blue</source>
        <translation>Blau</translation>
    </message>
    <message>
        <location filename="startide.py" line="6304"/>
        <source>yellow</source>
        <translation>Gelb</translation>
    </message>
    <message>
        <location filename="startide.py" line="6308"/>
        <source>cyan</source>
        <translation>Türkis</translation>
    </message>
    <message>
        <location filename="startide.py" line="6312"/>
        <source>magenta</source>
        <translation>Violett</translation>
    </message>
    <message>
        <location filename="startide.py" line="6316"/>
        <source>cfw-blue</source>
        <translation>cfw-Blau</translation>
    </message>
    <message>
        <location filename="startide.py" line="6320"/>
        <source>white</source>
        <translation>Weiß</translation>
    </message>
    <message>
        <location filename="startide.py" line="6324"/>
        <source>grey</source>
        <translation>Grau</translation>
    </message>
    <message>
        <location filename="startide.py" line="6328"/>
        <source>black</source>
        <translation>Schwarz</translation>
    </message>
    <message>
        <location filename="startide.py" line="6289"/>
        <source>Colors</source>
        <translation>Farben</translation>
    </message>
</context>
<context>
    <name>ecl</name>
    <message>
        <location filename="startide.py" line="2324"/>
        <source>Condition</source>
        <translation>Bedingung</translation>
    </message>
    <message>
        <location filename="startide.py" line="6549"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="startide.py" line="3201"/>
        <source>Direction</source>
        <translation>Drehrichtung</translation>
    </message>
    <message>
        <location filename="startide.py" line="3207"/>
        <source>right</source>
        <translation>rechts</translation>
    </message>
    <message>
        <location filename="startide.py" line="3207"/>
        <source>left</source>
        <translation>links</translation>
    </message>
    <message>
        <location filename="startide.py" line="3207"/>
        <source>stop</source>
        <translation>stop</translation>
    </message>
    <message>
        <location filename="startide.py" line="3013"/>
        <source>End Sw.</source>
        <translation>Endschalter</translation>
    </message>
    <message>
        <location filename="startide.py" line="2801"/>
        <source>Pulse Inp.</source>
        <translation>Impulseingang</translation>
    </message>
    <message>
        <location filename="startide.py" line="3335"/>
        <source>Pulses</source>
        <translation>Impulse</translation>
    </message>
    <message>
        <location filename="startide.py" line="3223"/>
        <source>Sync to</source>
        <translation>Sync mit</translation>
    </message>
    <message>
        <location filename="startide.py" line="3366"/>
        <source>Loop target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="3479"/>
        <source>Count</source>
        <translation>Anzahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="7310"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="8790"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="8759"/>
        <source>No Tags defined!</source>
        <translation>Keine Tags definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="8804"/>
        <source>No Modules defined!</source>
        <translation>Keine Module definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="8826"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="4590"/>
        <source>Inp. type</source>
        <translation>Eing.-Art</translation>
    </message>
    <message>
        <location filename="startide.py" line="6392"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="startide.py" line="2155"/>
        <source>WaitInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4553"/>
        <source>Device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4571"/>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4313"/>
        <source>Timeout</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2264"/>
        <source>TOut</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8500"/>
        <source>IfInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2427"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2546"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2695"/>
        <source>MotorP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2925"/>
        <source>MotorE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3135"/>
        <source>MotorES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8718"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4664"/>
        <source>switch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4664"/>
        <source>voltage</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4664"/>
        <source>resistance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4664"/>
        <source>distance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8963"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8685"/>
        <source>Comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8688"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8707"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8707"/>
        <source>Target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="8739"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8802"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8819"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8826"/>
        <source>BtnTxt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="119"/>
        <source>Variables</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="startide.py" line="106"/>
        <source>No Variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="119"/>
        <source>Select variable</source>
        <translation>Variable wählen</translation>
    </message>
    <message>
        <location filename="startide.py" line="4184"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="3534"/>
        <source>QueryIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3704"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5097"/>
        <source>Operator</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3950"/>
        <source>WaitIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8757"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8673"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8775"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4408"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4376"/>
        <source>Target module</source>
        <translation>Zielmodul</translation>
    </message>
    <message>
        <location filename="startide.py" line="8622"/>
        <source>Variable</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4437"/>
        <source>Variable name</source>
        <translation>Variablenname</translation>
    </message>
    <message>
        <location filename="startide.py" line="4507"/>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8533"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8643"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5080"/>
        <source>First Operand</source>
        <translation>Erster Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="5114"/>
        <source>Second Operand</source>
        <translation>Zweiter Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="5130"/>
        <source>Target variable</source>
        <translation>Zielvariable</translation>
    </message>
    <message>
        <location filename="startide.py" line="6023"/>
        <source>1st Op.</source>
        <translation>1. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="6046"/>
        <source>2nd Op.</source>
        <translation>2. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="8585"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5670"/>
        <source>Min value</source>
        <translation>Minimum</translation>
    </message>
    <message>
        <location filename="startide.py" line="5687"/>
        <source>Max value</source>
        <translation>Maximum</translation>
    </message>
    <message>
        <location filename="startide.py" line="5758"/>
        <source>Min</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5790"/>
        <source>Max</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5633"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8598"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5809"/>
        <source>Buttons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5839"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="5846"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="5905"/>
        <source>Btn. Text</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8517"/>
        <source>IfIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8622"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8909"/>
        <source>No variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="2367"/>
        <source>CounterClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4664"/>
        <source>counter</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8546"/>
        <source>FromPoly</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5306"/>
        <source>Input:</source>
        <translation>Eingangsvariable:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5463"/>
        <source>Target:</source>
        <translation>Zielvariable:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5348"/>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5357"/>
        <source>B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5366"/>
        <source>C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5375"/>
        <source>D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5417"/>
        <source>Input</source>
        <translation>Eingangsvariable</translation>
    </message>
    <message>
        <location filename="startide.py" line="8559"/>
        <source>FromSys</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5441"/>
        <source>Data:</source>
        <translation>Daten:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5918"/>
        <source>Pen</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5936"/>
        <source>Operation</source>
        <translation>Funktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="5952"/>
        <source>x position</source>
        <translation>x-Position</translation>
    </message>
    <message>
        <location filename="startide.py" line="5969"/>
        <source>y position</source>
        <translation>y-Position</translation>
    </message>
    <message>
        <location filename="startide.py" line="6055"/>
        <source>Color</source>
        <translation>Farbe</translation>
    </message>
    <message>
        <location filename="startide.py" line="6084"/>
        <source>Red:</source>
        <translation>Rot:</translation>
    </message>
    <message>
        <location filename="startide.py" line="6103"/>
        <source>Green:</source>
        <translation>Grün:</translation>
    </message>
    <message>
        <location filename="startide.py" line="6122"/>
        <source>Blue:</source>
        <translation>Blau:</translation>
    </message>
    <message>
        <location filename="startide.py" line="6157"/>
        <source>Presets</source>
        <translation>Vorgaben</translation>
    </message>
    <message>
        <location filename="startide.py" line="6209"/>
        <source>Red</source>
        <translation>Rot</translation>
    </message>
    <message>
        <location filename="startide.py" line="6233"/>
        <source>Green</source>
        <translation>Grün</translation>
    </message>
    <message>
        <location filename="startide.py" line="6258"/>
        <source>Blue</source>
        <translation>Blau</translation>
    </message>
    <message>
        <location filename="startide.py" line="6468"/>
        <source>Font type</source>
        <translation>Schrifttyp</translation>
    </message>
    <message>
        <location filename="startide.py" line="6485"/>
        <source>Font size</source>
        <translation>Schriftgröße</translation>
    </message>
    <message>
        <location filename="startide.py" line="8853"/>
        <source>VarToText</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8834"/>
        <source>RIFShift</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8660"/>
        <source>IfTouchArea</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4866"/>
        <source>x1:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4884"/>
        <source>y1:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4902"/>
        <source>x2:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4920"/>
        <source>y2:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8881"/>
        <source>Array</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6717"/>
        <source>Variable:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6598"/>
        <source>Action:</source>
        <translation>Aktion:</translation>
    </message>
    <message>
        <location filename="startide.py" line="6894"/>
        <source>Array:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6636"/>
        <source>at index</source>
        <translation>mit Index</translation>
    </message>
    <message>
        <location filename="startide.py" line="6691"/>
        <source>Index</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8907"/>
        <source>ArrayStat</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6737"/>
        <source>Function:</source>
        <translation>Funktion:</translation>
    </message>
    <message>
        <location filename="startide.py" line="8924"/>
        <source>ArrayLoad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6807"/>
        <source>Filename:</source>
        <translation>Dateiname:</translation>
    </message>
    <message>
        <location filename="startide.py" line="8941"/>
        <source>ArraySave</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6875"/>
        <source>File:</source>
        <translation>Datei:</translation>
    </message>
    <message>
        <location filename="startide.py" line="7858"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="startide.py" line="8864"/>
        <source>ArrayInit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8960"/>
        <source>No Arrays defined!</source>
        <translation>Keine Arrays definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="8970"/>
        <source>QueryArray</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="8970"/>
        <source>Select array</source>
        <translation>Array wählen</translation>
    </message>
</context>
<context>
    <name>exec</name>
    <message>
        <location filename="startide.py" line="384"/>
        <source>TXT not found!
Program terminated
</source>
        <translation>TXT nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="387"/>
        <source>RoboIF not found!
Program terminated
</source>
        <translation>RoboInterface nicht gefunden!
Programm abgebochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="405"/>
        <source>MEnd found with-
out Module!
Program terminated
</source>
        <translation>MEnd ohne Modul!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="408"/>
        <source>MEnd missing!
Program terminated
</source>
        <translation>MEnd fehlt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="411"/>
        <source>TXT M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>TXT M1 und O1/O2
gleichtzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="414"/>
        <source>TXT M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>TXT M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="417"/>
        <source>TXT M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>TXT M3 und O5/O6
gleichzeitig belegt.
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="229"/>
        <source>TXT M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="423"/>
        <source>RIF M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>RIF M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="426"/>
        <source>RIF M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>RIF M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="429"/>
        <source>RIF M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>RIF M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="241"/>
        <source>RIF M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="451"/>
        <source>M3 and M4 not available
on Robo LT!
Program terminated
</source>
        <translation>M3 und M4 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="454"/>
        <source>O5 to O8 not available
on Robo LT!
Program terminated
</source>
        <translation>O5 bis O8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="457"/>
        <source>I4 to I8 not available
on Robo LT!
Program terminated
</source>
        <translation>I4 bis I8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="7817"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="390"/>
        <source>ftduino not found!
Program terminated
</source>
        <translation>ftduino nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="435"/>
        <source>FTD M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>FTD M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="438"/>
        <source>FTD M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>FTD M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="441"/>
        <source>FTD M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>FTD M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="253"/>
        <source>FTD M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="420"/>
        <source>TXT M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="432"/>
        <source>RIF M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="444"/>
        <source>FTD M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="396"/>
        <source>TXT analog I</source>
        <translation>TXT Eingang I</translation>
    </message>
    <message>
        <location filename="startide.py" line="399"/>
        <source>
types inconsistent!
Program terminated
</source>
        <translation>Typen inkonsistent!
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="393"/>
        <source>External Module</source>
        <translation>Externes Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="393"/>
        <source>not found.
Program terminated
</source>
        <translation>nicht gefunden.
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="399"/>
        <source>FTD analog I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="402"/>
        <source>FTD counter C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="402"/>
        <source>
counter/distance mismatch!
Program terminated
</source>
        <translation>
counter/distance Unstimmigkeit!
Programm abgebrochen
</translation>
    </message>
</context>
<context>
    <name>m_about</name>
    <message>
        <location filename="startide.py" line="7176"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="7178"/>
        <source>A tiny IDE to control Robo Family Interfaces and TXT Hardware.</source>
        <translation>Eine Mini-IDE zum Steuern von Robo Interfaces und TXT Hardware.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>The manual is available in the webinterface under &apos;Get more app info&apos;.</source>
        <translation type="obsolete">Das Handbuch liegt im Webinterface unter &apos;Get more app info&apos;. </translation>
    </message>
    <message>
        <location filename="startide.py" line="7178"/>
        <source>The manual is available in the TXT startIDE webinterface under &apos;Get more app info&apos;.</source>
        <translation>Das Handbuch ist im TXT startIDE webinterface unter &apos;Get more app info&apos; verfügbar.</translation>
    </message>
    <message>
        <location filename="startide.py" line="7187"/>
        <source>News</source>
        <translation>News</translation>
    </message>
    <message>
        <location filename="startide.py" line="7183"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_interfaces</name>
    <message>
        <location filename="startide.py" line="7500"/>
        <source>No Robo device</source>
        <translation>Kein Robo Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="7503"/>
        <source>No TXT device</source>
        <translation>Kein TXT Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="7504"/>
        <source>TXT found</source>
        <translation>TXT gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="7509"/>
        <source>Hardware found:</source>
        <translation>Gefundene Hardware:</translation>
    </message>
    <message>
        <location filename="startide.py" line="7511"/>
        <source>Interfaces</source>
        <translation>Interfaces</translation>
    </message>
    <message>
        <location filename="startide.py" line="7506"/>
        <source>No ftduino device</source>
        <translation>Kein ftduino</translation>
    </message>
    <message>
        <location filename="startide.py" line="7507"/>
        <source>found</source>
        <translation>gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="7516"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7532"/>
        <source>Enable IIF</source>
        <translation>IIf aktivieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="7523"/>
        <source>Enabling IIF with any device other than an Intelligent Interface connected to &apos;/dev/ttyUSB0&apos; will crash startIDE.</source>
        <translation>Aktivieren des IIf ohne angeschlossenes Interface an /dev/ttyUSB0 führt zum Programmabsturz.</translation>
    </message>
    <message>
        <location filename="startide.py" line="7529"/>
        <source>Cancel</source>
        <translation>Abbrechen
</translation>
    </message>
</context>
<context>
    <name>m_modules</name>
    <message>
        <location filename="startide.py" line="7359"/>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="7424"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="7474"/>
        <source>No saved modules found.</source>
        <translation>Keine gespeicherten Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="7414"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="7407"/>
        <source>MEnd found with-
out Module!
Please fix before export!
</source>
        <translation>MEnd ohne Modul gefunden.
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="7416"/>
        <source>MEnd missing!
Please fix before export!
</source>
        <translation>MEnd fehlt!
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="7443"/>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="7428"/>
        <source>No modules found.</source>
        <translation>Keine Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="7445"/>
        <source>A module file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Modul mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="7490"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="7487"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="7482"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="7484"/>
        <source>Do you really want to permanently delete this module?</source>
        <translation>Soll das Modul wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="7476"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_project</name>
    <message>
        <location filename="startide.py" line="7199"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="7219"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <location filename="startide.py" line="7255"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="startide.py" line="7285"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="startide.py" line="7350"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="7241"/>
        <source>Current project was not saved. Do you want to discard it?</source>
        <translation>Projekt ist nicht gespeichert. Soll es gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="7330"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="7327"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="7314"/>
        <source>No saved projects found.</source>
        <translation>Keine gespeicherten Projekte.</translation>
    </message>
    <message>
        <location filename="startide.py" line="7276"/>
        <source>Enter project file name:</source>
        <translation>Projektnamen eingeben:</translation>
    </message>
    <message>
        <location filename="startide.py" line="7287"/>
        <source>A file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Projekt mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="7324"/>
        <source>Do you really want to permanently delete this project?</source>
        <translation>Soll das Projekt wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="7337"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="7348"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="startide.py" line="7349"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="startide.py" line="7316"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="startide.py" line="7627"/>
        <source>Close log</source>
        <translation>Schließe Log</translation>
    </message>
    <message>
        <location filename="startide.py" line="7087"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="7091"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="7879"/>
        <source>Start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="7881"/>
        <source>Stop</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>mmain</name>
    <message>
        <location filename="startide.py" line="7006"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="7011"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="7021"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="7016"/>
        <source>Interfaces</source>
        <translation></translation>
    </message>
</context>
</TS>
