<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>addcodeline</name>
    <message>
        <location filename="startide.py" line="2196"/>
        <source>New cmd:</source>
        <translation>Neuer Befehl:</translation>
    </message>
    <message>
        <location filename="startide.py" line="2212"/>
        <source>Inputs</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="2225"/>
        <source>Outputs</source>
        <translation>Ausgänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="2248"/>
        <source>Controls</source>
        <translation>Steuerung</translation>
    </message>
    <message>
        <location filename="startide.py" line="2269"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="2285"/>
        <source>Interaction</source>
        <translation>Interaktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="2221"/>
        <source>WaitForInputDig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2222"/>
        <source>IfInputDig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2241"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2242"/>
        <source>Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2243"/>
        <source>MotorPulsew.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2244"/>
        <source>MotorEnc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2245"/>
        <source>MotorEncSync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2261"/>
        <source># comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2262"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2263"/>
        <source>Jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2264"/>
        <source>LoopTo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2265"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2266"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2280"/>
        <source>Call</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2281"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2282"/>
        <source>Module</source>
        <translation type="unfinished">Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="2283"/>
        <source>MEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2286"/>
        <source>Interact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2297"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2298"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2299"/>
        <source>Message</source>
        <translation type="unfinished">Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="2287"/>
        <source>Request</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ecl</name>
    <message>
        <location filename="startide.py" line="604"/>
        <source>WaitInDig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1333"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1348"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="742"/>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="663"/>
        <source>Timeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1534"/>
        <source>TOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2448"/>
        <source>IfInDig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="778"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1459"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="startide.py" line="865"/>
        <source>Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1379"/>
        <source>Direction</source>
        <translation>Drehrichtung</translation>
    </message>
    <message>
        <location filename="startide.py" line="1385"/>
        <source>right</source>
        <translation>rechts</translation>
    </message>
    <message>
        <location filename="startide.py" line="1385"/>
        <source>left</source>
        <translation>links</translation>
    </message>
    <message>
        <location filename="startide.py" line="1385"/>
        <source>stop</source>
        <translation>stop</translation>
    </message>
    <message>
        <location filename="startide.py" line="982"/>
        <source>MotorP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1242"/>
        <source>End Sw.</source>
        <translation>Endschalter</translation>
    </message>
    <message>
        <location filename="startide.py" line="1080"/>
        <source>Pulse Inp.</source>
        <translation>Impulseingang</translation>
    </message>
    <message>
        <location filename="startide.py" line="1466"/>
        <source>Pulses</source>
        <translation>Impulse</translation>
    </message>
    <message>
        <location filename="startide.py" line="1160"/>
        <source>MotorE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1319"/>
        <source>MotorES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1401"/>
        <source>Sync to</source>
        <translation>Sync mit</translation>
    </message>
    <message>
        <location filename="startide.py" line="2493"/>
        <source>LoopTo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="1494"/>
        <source>Loop target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="1510"/>
        <source>Count</source>
        <translation>Anzahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="1886"/>
        <source>Project</source>
        <translation type="unfinished">Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="2527"/>
        <source>Module</source>
        <translation type="unfinished">Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="2495"/>
        <source>No Tags defined!</source>
        <translation>Keine Tags definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="2541"/>
        <source>Okay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2460"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2463"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2482"/>
        <source>Jump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2546"/>
        <source>Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2511"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2546"/>
        <source>Call</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2538"/>
        <source>No Modules defined!</source>
        <translation>Keine Module definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="2552"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="startide.py" line="2556"/>
        <source>Message</source>
        <translation type="unfinished">Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="2556"/>
        <source>BtnTxt</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>exec</name>
    <message>
        <location filename="startide.py" line="170"/>
        <source>TXT not found!
Program terminated
</source>
        <translation>TXT nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="173"/>
        <source>RoboIF not found!
Program terminated
</source>
        <translation>RoboInterface nicht gefunden!
Programm abgebochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="176"/>
        <source>MEnd found with-
out Module!
Program terminated
</source>
        <translation>MEnd ohne Modul!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="179"/>
        <source>MEnd missing!
Program terminated
</source>
        <translation>MEnd fehlt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="182"/>
        <source>TXT M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>TXT M1 und O1/O2
gleichtzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="185"/>
        <source>TXT M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>TXT M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="188"/>
        <source>TXT M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>TXT M3 und O5/O6
gleichzeitig belegt.
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="191"/>
        <source>TXT M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="194"/>
        <source>RIF M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>RIF M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="197"/>
        <source>RIF M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>RIF M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="200"/>
        <source>RIF M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>RIF M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="203"/>
        <source>RIF M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="211"/>
        <source>M3 and M4 not available
on Robo LT!
Program terminated
</source>
        <translation>M3 und M4 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="214"/>
        <source>O5 to O8 not available
on Robo LT!
Program terminated
</source>
        <translation>O5 bis O8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="217"/>
        <source>I4 to I8 not available
on Robo LT!
Program terminated
</source>
        <translation>I4 bis I8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="2161"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
</context>
<context>
    <name>m_about</name>
    <message>
        <location filename="startide.py" line="1752"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>A tiny IDE to control Robo Family Interfaces and TXT Hardware.</source>
        <translation>Eine Mini-IDE zum Steuern von Robo Interfaces und TXT Hardware.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>The manual is available in the webinterface under &apos;Get more app info&apos;.</source>
        <translation type="obsolete">Das Handbuch liegt im Webinterface unter &apos;Get more app info&apos;. </translation>
    </message>
    <message>
        <location filename="startide.py" line="1759"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>The manual is available in the TXT startIDE webinterface under &apos;Get more app info&apos;.</source>
        <translation>Das Handbuch ist im TXT startIDE webinterface unter &apos;Get more app info&apos; verfügbar.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1763"/>
        <source>News</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>m_interfaces</name>
    <message>
        <location filename="startide.py" line="2074"/>
        <source>No Robo device</source>
        <translation>Kein Robo Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="2077"/>
        <source>No TXT device</source>
        <translation>Kein TXT Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="2078"/>
        <source>TXT found</source>
        <translation>TXT gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="2080"/>
        <source>Hardware found:</source>
        <translation>Gefundene Hardware:</translation>
    </message>
    <message>
        <location filename="startide.py" line="2082"/>
        <source>Interfaces</source>
        <translation>Interfaces</translation>
    </message>
    <message>
        <location filename="startide.py" line="2087"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_modules</name>
    <message>
        <location filename="startide.py" line="1935"/>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="1999"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="2049"/>
        <source>No saved modules found.</source>
        <translation>Keine gespeicherten Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="2051"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1989"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="1982"/>
        <source>MEnd found with-
out Module!
Please fix before export!
</source>
        <translation>MEnd ohne Modul gefunden.
Bitte vor Export reparieren.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1991"/>
        <source>MEnd missing!
Please fix before export!
</source>
        <translation>MEnd fehlt!
Bitte vor Export reparieren.</translation>
    </message>
    <message>
        <location filename="startide.py" line="2018"/>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="2003"/>
        <source>No modules found.</source>
        <translation>Keine Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="2020"/>
        <source>A module file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Modul mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="2065"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="2062"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="2057"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="2059"/>
        <source>Do you really want to permanently delete this module?</source>
        <translation>Soll das Modul wirklich für immer gelöscht werden?</translation>
    </message>
</context>
<context>
    <name>m_project</name>
    <message>
        <location filename="startide.py" line="1775"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="1795"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <location filename="startide.py" line="1831"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="startide.py" line="1861"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="startide.py" line="1926"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="1817"/>
        <source>Current project was not saved. Do you want to discard it?</source>
        <translation>Projekt ist nicht gespeichert. Soll es gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="1906"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="1903"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="1890"/>
        <source>No saved projects found.</source>
        <translation>Keine gespeicherten Projekte!</translation>
    </message>
    <message>
        <location filename="startide.py" line="1892"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1852"/>
        <source>Enter project file name:</source>
        <translation>Projektnamen eingeben:</translation>
    </message>
    <message>
        <location filename="startide.py" line="1863"/>
        <source>A file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Projekt mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="1900"/>
        <source>Do you really want to permanently delete this project?</source>
        <translation>Soll das Projekt wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="1913"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="1924"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="startide.py" line="1925"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="startide.py" line="2183"/>
        <source>Start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2156"/>
        <source>Close log</source>
        <translation>Schließe Log</translation>
    </message>
    <message>
        <location filename="startide.py" line="2185"/>
        <source>Stop</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>mmain</name>
    <message>
        <location filename="startide.py" line="1598"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="1603"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="1608"/>
        <source>Interfaces</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1613"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
</context>
</TS>
