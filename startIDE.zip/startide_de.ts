<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>addcodeline</name>
    <message>
        <location filename="startide.py" line="5632"/>
        <source>New cmd:</source>
        <translation>Neuer Befehl:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5649"/>
        <source>Inputs</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="5672"/>
        <source>Outputs</source>
        <translation>Ausgänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="5741"/>
        <source>Controls</source>
        <translation>Steuerung</translation>
    </message>
    <message>
        <location filename="startide.py" line="5786"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5804"/>
        <source>Interaction</source>
        <translation>Interaktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="5661"/>
        <source>WaitForInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5663"/>
        <source>IfInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5688"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5689"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5690"/>
        <source>MotorPulsew.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5691"/>
        <source>MotorEnc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5692"/>
        <source>MotorEncSync</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5754"/>
        <source># comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5755"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5756"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5757"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5772"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5783"/>
        <source>Stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5798"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5800"/>
        <source>Return</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5801"/>
        <source>Module</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5802"/>
        <source>MEnd</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5805"/>
        <source>Interact</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5816"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5817"/>
        <source>Clear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5818"/>
        <source>Message</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5715"/>
        <source>Variables</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="startide.py" line="5665"/>
        <source>WaitForInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5667"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5669"/>
        <source>QueryInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5713"/>
        <source>Init</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5714"/>
        <source>From...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5736"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5737"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5738"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5730"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5731"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5732"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5733"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5735"/>
        <source>Shelf</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5759"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5773"/>
        <source>TimerQuery</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5775"/>
        <source>TimerClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5777"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5779"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5781"/>
        <source>QueryNow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5799"/>
        <source>CallExt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5940"/>
        <source>Logfile</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5950"/>
        <source>Log On</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5951"/>
        <source>Log Off</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5952"/>
        <source>Log Clear</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ecl</name>
    <message>
        <location filename="startide.py" line="1890"/>
        <source>Condition</source>
        <translation>Bedingung</translation>
    </message>
    <message>
        <location filename="startide.py" line="4339"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="startide.py" line="2705"/>
        <source>Direction</source>
        <translation>Drehrichtung</translation>
    </message>
    <message>
        <location filename="startide.py" line="2711"/>
        <source>right</source>
        <translation>rechts</translation>
    </message>
    <message>
        <location filename="startide.py" line="2711"/>
        <source>left</source>
        <translation>links</translation>
    </message>
    <message>
        <location filename="startide.py" line="2711"/>
        <source>stop</source>
        <translation>stop</translation>
    </message>
    <message>
        <location filename="startide.py" line="2517"/>
        <source>End Sw.</source>
        <translation>Endschalter</translation>
    </message>
    <message>
        <location filename="startide.py" line="2305"/>
        <source>Pulse Inp.</source>
        <translation>Impulseingang</translation>
    </message>
    <message>
        <location filename="startide.py" line="2839"/>
        <source>Pulses</source>
        <translation>Impulse</translation>
    </message>
    <message>
        <location filename="startide.py" line="2727"/>
        <source>Sync to</source>
        <translation>Sync mit</translation>
    </message>
    <message>
        <location filename="startide.py" line="2870"/>
        <source>Loop target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="2983"/>
        <source>Count</source>
        <translation>Anzahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="5275"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="6311"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="6280"/>
        <source>No Tags defined!</source>
        <translation>Keine Tags definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="6325"/>
        <source>No Modules defined!</source>
        <translation>Keine Module definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="6347"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="4096"/>
        <source>Inp. type</source>
        <translation>Eing.-Art</translation>
    </message>
    <message>
        <location filename="startide.py" line="3101"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="startide.py" line="1721"/>
        <source>WaitInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4059"/>
        <source>Device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4077"/>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3817"/>
        <source>Timeout</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1830"/>
        <source>TOut</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6064"/>
        <source>IfInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1931"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2050"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2199"/>
        <source>MotorP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2429"/>
        <source>MotorE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2639"/>
        <source>MotorES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6239"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4170"/>
        <source>switch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4170"/>
        <source>voltage</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4170"/>
        <source>resistance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4170"/>
        <source>distance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6328"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6206"/>
        <source>Comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6209"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6228"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6228"/>
        <source>Target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="6260"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6323"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6340"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6347"/>
        <source>BtnTxt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="99"/>
        <source>Variables</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="startide.py" line="86"/>
        <source>No Variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="99"/>
        <source>Select variable</source>
        <translation>Variable wählen</translation>
    </message>
    <message>
        <location filename="startide.py" line="3688"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="3038"/>
        <source>QueryIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3208"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4383"/>
        <source>Operator</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3454"/>
        <source>WaitIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6278"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6194"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6296"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3912"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3880"/>
        <source>Target module</source>
        <translation>Zielmodul</translation>
    </message>
    <message>
        <location filename="startide.py" line="6160"/>
        <source>Variable</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3941"/>
        <source>Variable name</source>
        <translation>Variablenname</translation>
    </message>
    <message>
        <location filename="startide.py" line="4011"/>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4043"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6181"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4366"/>
        <source>First Operand</source>
        <translation>Erster Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4400"/>
        <source>Second Operand</source>
        <translation>Zweiter Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4416"/>
        <source>Target variable</source>
        <translation>Zielvariable</translation>
    </message>
    <message>
        <location filename="startide.py" line="4469"/>
        <source>1st Op.</source>
        <translation>1. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4492"/>
        <source>2nd Op.</source>
        <translation>2. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="6123"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4676"/>
        <source>Min value</source>
        <translation>Minimum</translation>
    </message>
    <message>
        <location filename="startide.py" line="4693"/>
        <source>Max value</source>
        <translation>Maximum</translation>
    </message>
    <message>
        <location filename="startide.py" line="4764"/>
        <source>Min</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4796"/>
        <source>Max</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4639"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6136"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4815"/>
        <source>Buttons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4845"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="4852"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="4911"/>
        <source>Btn. Text</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6081"/>
        <source>IfIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6160"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6196"/>
        <source>No variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
</context>
<context>
    <name>exec</name>
    <message>
        <location filename="startide.py" line="339"/>
        <source>TXT not found!
Program terminated
</source>
        <translation>TXT nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="342"/>
        <source>RoboIF not found!
Program terminated
</source>
        <translation>RoboInterface nicht gefunden!
Programm abgebochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="360"/>
        <source>MEnd found with-
out Module!
Program terminated
</source>
        <translation>MEnd ohne Modul!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="363"/>
        <source>MEnd missing!
Program terminated
</source>
        <translation>MEnd fehlt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="366"/>
        <source>TXT M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>TXT M1 und O1/O2
gleichtzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="369"/>
        <source>TXT M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>TXT M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="372"/>
        <source>TXT M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>TXT M3 und O5/O6
gleichzeitig belegt.
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="229"/>
        <source>TXT M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="378"/>
        <source>RIF M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>RIF M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="381"/>
        <source>RIF M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>RIF M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="384"/>
        <source>RIF M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>RIF M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="241"/>
        <source>RIF M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="406"/>
        <source>M3 and M4 not available
on Robo LT!
Program terminated
</source>
        <translation>M3 und M4 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="409"/>
        <source>O5 to O8 not available
on Robo LT!
Program terminated
</source>
        <translation>O5 bis O8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="412"/>
        <source>I4 to I8 not available
on Robo LT!
Program terminated
</source>
        <translation>I4 bis I8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5567"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="345"/>
        <source>ftduino not found!
Program terminated
</source>
        <translation>ftduino nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="390"/>
        <source>FTD M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>FTD M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="393"/>
        <source>FTD M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>FTD M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="396"/>
        <source>FTD M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>FTD M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="253"/>
        <source>FTD M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="375"/>
        <source>TXT M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="387"/>
        <source>RIF M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="399"/>
        <source>FTD M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="351"/>
        <source>TXT analog I</source>
        <translation>TXT Eingang I</translation>
    </message>
    <message>
        <location filename="startide.py" line="354"/>
        <source>
types inconsistent!
Program terminated
</source>
        <translation>Typen inkonsistent!
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="348"/>
        <source>External Module</source>
        <translation>Externes Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="348"/>
        <source>not found.
Program terminated
</source>
        <translation>nicht gefunden.
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="354"/>
        <source>FTD analog I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="357"/>
        <source>FTD counter C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="357"/>
        <source>
counter/distance mismatch!
Program terminated
</source>
        <translation>
counter/distance Unstimmigkeit!
Programm abgebrochen
</translation>
    </message>
</context>
<context>
    <name>m_about</name>
    <message>
        <location filename="startide.py" line="5141"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="5143"/>
        <source>A tiny IDE to control Robo Family Interfaces and TXT Hardware.</source>
        <translation>Eine Mini-IDE zum Steuern von Robo Interfaces und TXT Hardware.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>The manual is available in the webinterface under &apos;Get more app info&apos;.</source>
        <translation type="obsolete">Das Handbuch liegt im Webinterface unter &apos;Get more app info&apos;. </translation>
    </message>
    <message>
        <location filename="startide.py" line="5143"/>
        <source>The manual is available in the TXT startIDE webinterface under &apos;Get more app info&apos;.</source>
        <translation>Das Handbuch ist im TXT startIDE webinterface unter &apos;Get more app info&apos; verfügbar.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5152"/>
        <source>News</source>
        <translation>News</translation>
    </message>
    <message>
        <location filename="startide.py" line="5148"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_interfaces</name>
    <message>
        <location filename="startide.py" line="5464"/>
        <source>No Robo device</source>
        <translation>Kein Robo Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="5467"/>
        <source>No TXT device</source>
        <translation>Kein TXT Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="5468"/>
        <source>TXT found</source>
        <translation>TXT gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5473"/>
        <source>Hardware found:</source>
        <translation>Gefundene Hardware:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5475"/>
        <source>Interfaces</source>
        <translation>Interfaces</translation>
    </message>
    <message>
        <location filename="startide.py" line="5470"/>
        <source>No ftduino device</source>
        <translation>Kein ftduino</translation>
    </message>
    <message>
        <location filename="startide.py" line="5471"/>
        <source>found</source>
        <translation>gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5480"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_modules</name>
    <message>
        <location filename="startide.py" line="5324"/>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="5389"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="5439"/>
        <source>No saved modules found.</source>
        <translation>Keine gespeicherten Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5379"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5372"/>
        <source>MEnd found with-
out Module!
Please fix before export!
</source>
        <translation>MEnd ohne Modul gefunden.
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="5381"/>
        <source>MEnd missing!
Please fix before export!
</source>
        <translation>MEnd fehlt!
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="5408"/>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="5393"/>
        <source>No modules found.</source>
        <translation>Keine Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5410"/>
        <source>A module file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Modul mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5455"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="5452"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="5447"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5449"/>
        <source>Do you really want to permanently delete this module?</source>
        <translation>Soll das Modul wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5441"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_project</name>
    <message>
        <location filename="startide.py" line="5164"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="5184"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <location filename="startide.py" line="5220"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5250"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="startide.py" line="5315"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5206"/>
        <source>Current project was not saved. Do you want to discard it?</source>
        <translation>Projekt ist nicht gespeichert. Soll es gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5295"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="5292"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="5279"/>
        <source>No saved projects found.</source>
        <translation>Keine gespeicherten Projekte.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5241"/>
        <source>Enter project file name:</source>
        <translation>Projektnamen eingeben:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5252"/>
        <source>A file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Projekt mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5289"/>
        <source>Do you really want to permanently delete this project?</source>
        <translation>Soll das Projekt wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5302"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5313"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="startide.py" line="5314"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="startide.py" line="5281"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="startide.py" line="5562"/>
        <source>Close log</source>
        <translation>Schließe Log</translation>
    </message>
    <message>
        <location filename="startide.py" line="5062"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="5066"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="5619"/>
        <source>Start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5621"/>
        <source>Stop</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>mmain</name>
    <message>
        <location filename="startide.py" line="4981"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="4986"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="4996"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="4991"/>
        <source>Interfaces</source>
        <translation></translation>
    </message>
</context>
</TS>
