#! /usr/bin/env python3
# -*- coding: utf-8 -*-
#
import sys
from TouchStyle import *
from TouchAuxiliary import *

class FtcGuiApplication(TouchApplication):
    def __init__(self, args):
        TouchApplication.__init__(self, args)
        
        #define variables for test
        code=[ "# test",
               "Output Robo 1 Set 7",
               "Delay 1000",
               "Output Robo 1 Set 0"
             ]
        
        
        # init internationalisation
        translator = QTranslator()
        path = os.path.dirname(os.path.realpath(__file__))
        translator.load(QLocale.system(), os.path.join(path, "startide_"))
        self.installTranslator(translator)

        # create the empty main window
        self.mainwindow = TouchWindow("startIDE")
        
        # and the central widget
        self.centralwidget=QWidget()
        
        #
        l=QVBoxLayout()

        
        self.proglist=QListWidget()
        self.proglist.setStyleSheet("font-family: 'Monospace'; font-size: 12px;")
        
        c=999
        for a in code:
            self.proglist.addItem(("   "+str(c))[-4:]+ ": "+a)
            c=c+1
            
        l.addWidget(self.proglist)
        
        self.centralwidget.setLayout(l)
        self.mainwindow.setCentralWidget(self.centralwidget)
        
        self.mainwindow.show()
        self.exec_()        

if __name__ == "__main__":
    FtcGuiApplication(sys.argv)
